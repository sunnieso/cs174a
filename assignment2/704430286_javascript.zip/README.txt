CS 174a Assignment Two, Spring 2016
"Save the Drought!"

Student Name: Sunnie So
UID: <704430286>

This is a game.
The robot needs to travel to the sea world to collect valuable raindrop, and bring the raindrop back to Los Angeles in order to save the drought. 
When the robot collect enough raindrops in the bucket, it should return to Los Angeles.
my custom shapes are tetrahedron_share and tetrahedron. Namely, faces of tetrahedron_share share the vertices, and faces of tetrahedron does not.


Requirement explanation:
[ROBOT arms and legs] 	<== Show at least one two-level hierarchical object 
[camera follows robot] 	<== Demonstrate the camera tracking a moving object using lookAt().
[tetrahedron]  			<== Design polygonal objects of your own. You must provide positions, normals, and texture coordinates directly, by extending the Shape class.
[tetrahedron]      		<== For one of your custom polygonal objects, show at least one flat-shaded seam (a discontinuous edge) and light it with the Phong reflection model.
[most of my objects] <== Texture one of your custom polygonal objects procedurally or by mapping an image.


Controls:
use "a s d w" to move the robot
