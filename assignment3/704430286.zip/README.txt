Simple Ray Tracing, CS174a Spring 2016, Sunnie So 

Handle simple diffuse, specular, shading, and reflection on spheres.

Main functions explanations:
	trace() : main tracing function. Also handle reflection color component by recursive function calls.
	shadow_ray() : calculation local color component. (diffuse and specular and shadow)
	find_closest_intersection() : namly.

Passed test files: ALL 